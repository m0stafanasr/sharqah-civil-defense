import React from 'react';
import './welcome.css'

function Welcom() {
  return <div className='wel '>
    welcome to 
     
    jumia<br/> Admin
     Panal
  </div>
}

export default Welcom;
